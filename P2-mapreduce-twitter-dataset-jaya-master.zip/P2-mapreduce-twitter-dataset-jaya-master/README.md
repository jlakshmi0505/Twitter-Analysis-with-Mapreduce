# Project 2: MapReduce

See the project spec here: https://www.cs.usfca.edu/~mmalensek/cs677/assignments/project-2.html
